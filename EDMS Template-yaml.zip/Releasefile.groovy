// Exported from:        http://AnkurTrvedisMBP.fios-router.home:5516/#/templates/Folder402782d9216c4c0eb8f061a829ca4504-Release8dbbdc6d735842d99843a976fea3f316/releasefile
// XL Release version:   9.6.0-alpha.84
// Date created:         Tue Mar 17 16:00:42 EDT 2020

xlr {
  template('EDMS Template-yaml') {
    folder('Freedom Mortgage')
    variables {
      stringVariable('lbFileData') {
        required false
        showOnReleaseStart false
      }
      stringVariable('testTargetGroup') {
        required false
        showOnReleaseStart false
      }
      stringVariable('testEc2InstanceId') {
        required false
        showOnReleaseStart false
      }
      stringVariable('testPort') {
        required false
        showOnReleaseStart false
      }
      stringVariable('deregisterTestCommand') {
        required false
        showOnReleaseStart false
      }
      stringVariable('registerTestCommand') {
        required false
        showOnReleaseStart false
      }
      stringVariable('deregisterUATCommand') {
        required false
        showOnReleaseStart false
      }
      stringVariable('registerUATCommand') {
        required false
        showOnReleaseStart false
      }
      stringVariable('registerProdCommand') {
        required false
        showOnReleaseStart false
      }
      stringVariable('deregisterProdCommand') {
        required false
        showOnReleaseStart false
      }
    }
    scheduledStartDate Date.parse("yyyy-MM-dd'T'HH:mm:ssZ", '2020-03-12T09:00:00-0400')
    scriptUserPassword '{aes:v0}BsXlYrYecBKrfrTopKEJ3Yl5/9I3GqEbDWJpdX8xhyU='
    phases {
      phase('Get LB data from repo') {
        color '#0079BC'
        tasks {
          custom('Get File') {
            script {
              type 'http.GetFile'
              server 'https://raw.githubusercontent.com/'
              username 'ankurtrivedi'
              password '{aes:v0}r5nshuXYBPzKZGH8zhP4TXC/zGZRjqepusgWzGjK33k='
              uri 'xebialabs-external/freedom-mortgage-implementation/master/CD.yml'
              fileContent variable('lbFileData')
            }
          }
          script('Parse file data and populate variables') {
            script (['''\
import yaml

loadedJson = yaml.load(releaseVariables['lbFileData'])


# Load Test environment Variables

test = loadedJson["test"]

targetGroup = ""
targetID = ""
port = 0

for app in test.keys():
    if app == "hubsoap":
        targetGroup=  loadedJson["test"]["hubsoap"][0]["targetGroup"]
        targetID = loadedJson["test"]["hubsoap"][0]["ec2Instance"][0]["id"]
        port = loadedJson["test"]["hubsoap"][0]["instances"][0]["port"]


releaseVariables['deregisterTestCommand'] = "aws elbv2 deregister-targets --region us-east-1 --target-group-arn " + targetGroup +" --targets Id=" +targetID + ",Port="+str(port)
releaseVariables['registerTestCommand'] = "aws elbv2 register-targets --region us-east-1 --target-group-arn " + targetGroup +" --targets Id=" +targetID + ",Port="+str(port)

# Load UAT environment Variables


uat = loadedJson["uat"]

targetUATGroup = ""
targetUATID = ""
uatPort = ""

deregisterUATCommand = ""
registerUATCommand = ""

for app in uat.keys():
    if app == "hubsoap":
        targetGroup=  loadedJson["uat"]["hubsoap"][0]["targetGroup"]
        for instance in range(len(loadedJson["uat"]["hubsoap"][0]["ec2Instance"])):
            targetUATInstanceID = loadedJson["uat"]["hubsoap"][0]["ec2Instance"][instance]["id"]
            uatPort = ""
            for p in range(len(loadedJson["uat"]["hubsoap"][0]["ec2Instance"][instance]["instances"])):
                uatPort += str(loadedJson["uat"]["hubsoap"][0]["ec2Instance"][instance]["instances"][p]["port"])+","
            
            deregisterUATCommand +=   "\\n aws elbv2 deregister-targets --region us-east-1 --target-group-arn " + targetGroup +" --targets Id=" +targetUATInstanceID + ",Port="+uatPort
            registerUATCommand +=  "\\n aws elbv2 register-targets --region us-east-1 --target-group-arn " + targetGroup +" --targets Id=" +targetUATInstanceID + ",Port="+uatPort


releaseVariables['deregisterUATCommand'] = deregisterUATCommand
releaseVariables['registerUATCommand'] = registerUATCommand
'''])
          }
        }
      }
      phase('Deploy Test') {
        color '#0079BC'
        tasks {
          custom('deregister LB') {
            script {
              type 'remoteScript.Unix'
              script '${deregisterTestCommand}'
            }
          }
          custom('Deploy') {
            script {
              type 'xldeploy.Deploy'
              retryCounter 'currentContinueRetrial':'0','currentPollingTrial':'0'
            }
          }
          custom('register LB') {
            script {
              type 'remoteScript.Unix'
              script '${registerTestCommand}'
            }
          }
        }
      }
      phase('Deploy UAT') {
        color '#0079BC'
        tasks {
          custom('deregister LB') {
            script {
              type 'remoteScript.Unix'
              script '${deregisterUATCommand}'
            }
          }
          custom('Deploy') {
            script {
              type 'xldeploy.Deploy'
              server 'local XLD'
              retryCounter 'currentContinueRetrial':'0','currentPollingTrial':'0'
            }
          }
          custom('register LB') {
            script {
              type 'remoteScript.Unix'
              script '${registerUATCommand}'
            }
          }
        }
      }
      phase('Deploy Prod') {
        color '#0079BC'
        tasks {
          custom('deregister LB') {
            script {
              type 'remoteScript.Unix'
              script '${deregisterProdCommand}'
            }
          }
          custom('Deploy') {
            script {
              type 'xldeploy.Deploy'
              server 'local XLD'
              retryCounter 'currentContinueRetrial':'0','currentPollingTrial':'0'
            }
          }
          custom('register LB') {
            script {
              type 'remoteScript.Unix'
              script '${registerProdCommand}'
            }
          }
        }
      }
    }
    
  }
}