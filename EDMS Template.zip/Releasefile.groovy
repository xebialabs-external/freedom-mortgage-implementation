// Exported from:        http://AnkurTrvedisMBP.fios-router.home:5516/#/templates/Folder402782d9216c4c0eb8f061a829ca4504-Release6982395bd7944135bc292814900d0cd7/releasefile
// XL Release version:   9.6.0-alpha.84
// Date created:         Thu Mar 12 15:58:50 EDT 2020

xlr {
  template('EDMS Template') {
    folder('Freedom Mortgage')
    variables {
      stringVariable('lbFileData') {
        required false
        showOnReleaseStart false
      }
      stringVariable('testTargetGroup') {
        required false
        showOnReleaseStart false
      }
      stringVariable('testEc2InstanceId') {
        required false
        showOnReleaseStart false
      }
      stringVariable('testPort') {
        required false
        showOnReleaseStart false
      }
      stringVariable('deregisterCommand') {
        required false
        showOnReleaseStart false
      }
      stringVariable('registerCommand') {
        required false
        showOnReleaseStart false
      }
    }
    scheduledStartDate Date.parse("yyyy-MM-dd'T'HH:mm:ssZ", '2020-03-12T09:00:00-0400')
    scriptUserPassword '{aes:v0}vI4JF45wkwLKAYJlqtTnP7T/UNllH57nSNdNcUzCOIQ='
    phases {
      phase('Get LB data from repo') {
        color '#0079BC'
        tasks {
          custom('Get File') {
            script {
              type 'http.GetFile'
              server 'https://raw.githubusercontent.com/'
              username 'ankurtrivedi'
              password '{aes:v0}r5nshuXYBPzKZGH8zhP4TXC/zGZRjqepusgWzGjK33k='
              uri 'xebialabs-external/freedom-mortgage-implementation/master/loadbalancer.json'
              fileContent variable('lbFileData')
            }
          }
          script('Parse file data and populate variables') {
            script (['''\
import json

loadedJson = json.loads(releaseVariables['lbFileData'])


applicationName = loadedJson.get("application").get("applicationName")

targetGroup=  loadedJson.get("test").get(applicationName)[0].get("targetGroup")

targetID = loadedJson.get("test").get(applicationName)[0].get("ec2Instance")[0].get("id")
port = str(loadedJson.get("test").get(applicationName)[0].get("instances")[0].get("port"))

print targetGroup
print targetID
print port

releaseVariables['deregisterCommand'] = "aws elbv2 deregister-targets --region us-east-1 --target-group-arn " + targetGroup +" --targets Id=" +targetID + ",Port="+port
releaseVariables['registerCommand'] = "aws elbv2 register-targets --region us-east-1 --target-group-arn " + targetGroup +" --targets Id=" +targetID + ",Port="+port
'''])
          }
        }
      }
      phase('Deploy') {
        color '#0079BC'
        tasks {
          custom('deregister LB') {
            script {
              type 'remoteScript.Unix'
              script '${deregisterCommand}'
            }
          }
          custom('Deploy') {
            script {
              type 'xldeploy.Deploy'
              retryCounter 'currentContinueRetrial':'0','currentPollingTrial':'0'
            }
          }
          custom('register LB') {
            script {
              type 'remoteScript.Unix'
              script '${registerCommand}'
            }
          }
        }
      }
    }
    
  }
}